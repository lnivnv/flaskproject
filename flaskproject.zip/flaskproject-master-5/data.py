def Articles():
    tests = [
        {
            'id': 1,
            'title': 'Test One',
            'body': 'harry potter',
            'author': 'Masha Shamina',
            'create_date': '11-04-2022'
        },
        {
            'id': 2,
            'title': 'Test Two',
            'body': 'harry potter',
            'author': 'Masha Shamina',
            'create_date': '11-04-2022'
        },
        {
            'id': 3,
            'title': 'Test Three',
            'body': 'harry potter',
            'author': 'Masha Shamina',
            'create_date': '11-04-2022'
        }
    ]
    return tests